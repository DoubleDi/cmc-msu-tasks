#include <stdio.h>
#include <stdlib.h>

#ifndef H_GRANDFATHER
#define H_GRANDFATHER
    long rand_range(long low, long high);
#endif